﻿# Progress in a Nutshell

This is currently a prototype of a Kurzgesagt game concept we are working on in godot.


## Info:

A strategy like game which is a middle ground between civilizations and Clash of Clans
You start at the dawn of Duck kind(Humanity) and gradually evolve


## People working on it:

- Falderappes (contributing ideas)
- Deejah (contributing ideas)
- Triw (contributing ideas)
- Saf (contributing ideas)
- Benji ( @Benjimanrich contributing ideas, moral support and some git stuff from termux)
- Xtreme (AKA @infinitygamer404, the one who made this repo because smv was busy)
- s-mv ( @s-mv actually knows quite a bit of godot)
- Nigul\_senpai(contributing ideas)
- RedMelonShark(Art and Graphics)
- Potato(May help with godot soon+ideas)
- Coder(Godot and ideas)
